.. _optimize.root-krylov:

root(method='krylov')
--------------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_krylov_doc
   :method: krylov
