.. automodule:: scipy.optimize
   :no-members:
   :no-inherited-members:
   :no-special-members:
