.. _optimize.minimize-cobyqa:

minimize(method='COBYQA')
-------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._cobyqa_py._minimize_cobyqa
   :method: COBYQA
