.. _optimize.minimize-newtoncg:

minimize(method='Newton-CG')
-------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._optimize._minimize_newtoncg
   :method: Newton-CG
