.. _optimize.minimize-cobyla:

minimize(method='COBYLA')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._cobyla_py._minimize_cobyla
   :method: COBYLA
