.. _optimize.linprog-highs-ipm:

linprog(method='highs-ipm')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_highs_ipm_doc
   :method: highs-ipm
