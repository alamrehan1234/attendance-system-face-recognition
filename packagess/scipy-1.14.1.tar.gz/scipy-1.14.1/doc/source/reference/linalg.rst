.. automodule:: scipy.linalg
   :no-members:
   :no-inherited-members:
   :no-special-members:
