.. _sparse.linalg.svds-propack:

svds(solver='propack')
----------------------------------------

.. scipy-optimize:function:: scipy.sparse.linalg.svds
   :impl: scipy.sparse.linalg._eigen._svds_doc._svds_propack_doc
   :method: propack
