.. raw:: html

   <div class="prename">{{ module }}.</div>
   <div class="empty"></div>

{{ name }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}