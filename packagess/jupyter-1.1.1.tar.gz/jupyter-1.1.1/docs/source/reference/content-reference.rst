Reference
=========

.. toctree::
   :maxdepth: 1

   mimetype.md
   ./ipython
   ../glossary


Resources
---------

- :ref:`genindex`
- :ref:`search`