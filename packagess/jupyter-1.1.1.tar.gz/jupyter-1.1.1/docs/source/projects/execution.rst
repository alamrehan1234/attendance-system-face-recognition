=========
Execution
=========

Notebooks can be run outside of the browser interface with the following utility subprojects.

.. glossary::

    `nbclient <https://nbclient.readthedocs.io/en/latest/>`__
        NBClient lets you execute notebooks from different contexts, including the command-line.
        `Documentation <https://nbclient.readthedocs.io/en/latest/>`__ |
        `Repo <https://github.com/jupyter/nbclient>`__
