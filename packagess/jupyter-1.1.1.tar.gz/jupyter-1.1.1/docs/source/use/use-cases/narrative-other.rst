Narratives - Building blocks
============================

.. contents:: Contents
   :local:

Description
-----------

This section presents some examples of integrating different projects together.
These projects form the foundation of innovative services and provide
building blocks for future applications.

Narrative examples
------------------

- A Narrative about Creating Dashboards
- A Narrative about Thebe
- A Narrative about Hydrogen

.. note::

    We're actively working on this section of the documentation to improve
    it for you. Thanks for your patience.
