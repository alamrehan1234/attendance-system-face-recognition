Setting up a project's documentation infrastructure
===================================================

Contents:

.. toctree::
   :maxdepth: 1

   repo-structure.md
   doc-new-repos.md
   doc-new-build.md
   doc-new-translation.md

This section helps a contributor set up the documentation infrastructure for
a new project or an existing project without Sphinx documentation.